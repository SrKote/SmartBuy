import React, { useState, useEffect } from 'react';
import { Offer } from '../types';
import { Icons } from '../constants';
import BalanceChart from './BalanceChart';

interface OfferDetailModalProps {
  offer: Offer;
  monthlyYieldRate: number;
  onClose: () => void;
}

const formatCurrency = (val: number) => {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
};

const OfferDetailModal: React.FC<OfferDetailModalProps> = ({ offer, monthlyYieldRate, onClose }) => {
  const [installments, setInstallments] = useState(offer.installments);
  const [extraCashback, setExtraCashback] = useState(0);
  
  const [calculation, setCalculation] = useState({
    finalBalance: 0,
    isViable: false,
    adjustedInstallmentPrice: 0,
    monthlyPayment: 0
  });

  useEffect(() => {
    const decimalRate = monthlyYieldRate / 100;
    const cashbackFactor = 1 - (extraCashback / 100);
    
    const effectiveCashPrice = offer.cashPrice * cashbackFactor;
    const effectiveTotalInstallmentPrice = offer.installmentPrice * cashbackFactor;
    
    const n = Math.max(1, installments);
    const monthlyPayment = effectiveTotalInstallmentPrice / n;

    let balance = effectiveCashPrice;
    
    for (let i = 0; i < n; i++) {
        balance = balance * (1 + decimalRate);
        balance = balance - monthlyPayment;
    }

    setCalculation({
        finalBalance: balance,
        isViable: balance > 0,
        adjustedInstallmentPrice: effectiveTotalInstallmentPrice,
        monthlyPayment
    });

  }, [installments, extraCashback, offer.cashPrice, offer.installmentPrice, monthlyYieldRate]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-midnight-900/80 backdrop-blur-md transition-opacity" 
        onClick={onClose}
      ></div>

      <div className="bg-surface border border-white/10 rounded-3xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-y-auto relative z-10 animate-slide-up flex flex-col md:flex-row overflow-hidden">
        
        {/* Controls Column */}
        <div className="p-8 md:w-5/12 bg-midnight-900/50 border-b md:border-b-0 md:border-r border-white/5 relative">
            <button 
              onClick={onClose}
              className="absolute top-4 left-4 p-2 text-zinc-500 hover:text-white md:hidden"
            >
               <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>

            <div className="mb-10 mt-6 md:mt-0">
                <span className="text-primary-400 text-xs font-bold uppercase tracking-widest mb-3 block">{offer.store}</span>
                <h2 className="text-3xl font-bold text-white leading-tight mb-4">{offer.productName}</h2>
                <div className="flex flex-wrap gap-2">
                     {offer.exclusiveCondition && (
                        <span className="px-2 py-1 bg-accent-500/10 border border-accent-500/20 text-accent-300 text-[10px] font-bold uppercase rounded">
                            {offer.exclusiveCondition}
                        </span>
                     )}
                     <span className="px-2 py-1 bg-zinc-800 text-zinc-300 text-[10px] font-bold uppercase rounded">
                        {offer.paymentMethod || 'Padrão'}
                     </span>
                </div>
            </div>

            <div className="space-y-8">
                <div>
                    <h3 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                         Personalizar Cenário
                    </h3>
                    
                    <div className="space-y-6">
                        <div>
                            <div className="flex justify-between text-xs mb-2">
                                <span className="text-zinc-400">Parcelas</span>
                                <span className="text-white font-bold">{installments}x</span>
                            </div>
                            <input 
                                type="range" 
                                min="1" 
                                max="24" 
                                value={installments} 
                                onChange={(e) => setInstallments(Number(e.target.value))}
                                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-primary-500"
                            />
                        </div>
                        <div>
                            <div className="flex justify-between text-xs mb-2">
                                <span className="text-zinc-400">Cashback Extra (Cartão)</span>
                                <span className="text-white font-bold">{extraCashback}%</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" 
                                max="20" 
                                step="0.5"
                                value={extraCashback} 
                                onChange={(e) => setExtraCashback(Number(e.target.value))}
                                className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-accent-500"
                            />
                        </div>
                    </div>
                </div>

                <div className="bg-surface-highlight rounded-2xl p-5 border border-white/5">
                    <div className="grid grid-cols-2 gap-8">
                        <div>
                            <p className="text-[10px] uppercase text-zinc-500 font-bold mb-1">Custo à Vista</p>
                            <p className="text-xl font-bold text-white">
                                {formatCurrency(offer.cashPrice * (1 - extraCashback/100))}
                            </p>
                        </div>
                        <div>
                            <p className="text-[10px] uppercase text-zinc-500 font-bold mb-1">Parcela Mensal</p>
                            <p className="text-xl font-bold text-white">
                                {formatCurrency(calculation.monthlyPayment)}
                            </p>
                        </div>
                    </div>
                </div>
                
                <a 
                    href={offer.link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="block w-full text-center bg-white text-midnight-900 py-4 rounded-xl font-bold transition-all hover:bg-zinc-200"
                >
                    Ir para Loja
                </a>
            </div>
        </div>

        {/* Data Column */}
        <div className="p-8 md:w-7/12 flex flex-col h-full overflow-y-auto bg-surface">
             <div className="flex justify-between items-start mb-8">
                 <div>
                     <h3 className="text-xl font-bold text-white mb-1">Projeção Financeira</h3>
                     <p className="text-sm text-zinc-400">
                         Baseado em rendimento de <span className="text-success-400 font-bold">{monthlyYieldRate.toFixed(2)}% a.m.</span>
                     </p>
                 </div>
                 <button onClick={onClose} className="hidden md:block p-2 text-zinc-500 hover:text-white bg-white/5 rounded-full transition-colors">
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                 </button>
             </div>

             <div className="bg-midnight-900/50 rounded-2xl border border-white/5 p-6 mb-8 min-h-[220px]">
                 <BalanceChart 
                    cashPrice={offer.cashPrice * (1 - extraCashback/100)}
                    installmentPrice={offer.installmentPrice * (1 - extraCashback/100)}
                    installments={installments}
                    monthlyYieldRate={monthlyYieldRate}
                 />
             </div>

             <div className={`p-6 rounded-2xl border mb-8 ${calculation.isViable ? 'bg-success-500/5 border-success-500/20' : 'bg-primary-500/5 border-primary-500/20'}`}>
                 <div className="flex items-center gap-3 mb-2">
                    <div className={`w-2 h-2 rounded-full ${calculation.isViable ? 'bg-success-500' : 'bg-primary-500'}`}></div>
                    <p className={`font-bold text-lg ${calculation.isViable ? 'text-success-400' : 'text-primary-400'}`}>
                        {calculation.isViable ? 'O Parcelamento compensa.' : 'O Pagamento à Vista compensa.'}
                    </p>
                 </div>
                 <p className="text-sm text-zinc-300 leading-relaxed">
                     {calculation.isViable 
                        ? `Mesmo pagando juros (se houver), deixar o dinheiro rendendo gera um saldo positivo final de ${formatCurrency(calculation.finalBalance)}.`
                        : `O desconto oferecido à vista é muito agressivo. Você deixaria de economizar ${formatCurrency(Math.abs(calculation.finalBalance))} se parcelasse.`
                     }
                 </p>
             </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {(offer.pros || offer.cons) && (
                    <div className="space-y-4">
                        {offer.pros && offer.pros.length > 0 && (
                            <div>
                                <h4 className="text-xs font-bold text-success-400 uppercase tracking-widest mb-3">Pontos Positivos</h4>
                                <ul className="text-xs text-zinc-400 space-y-2">
                                    {offer.pros.map((p, i) => <li key={i} className="flex gap-2"><span className="text-success-500">•</span> {p}</li>)}
                                </ul>
                            </div>
                        )}
                         {offer.cons && offer.cons.length > 0 && (
                            <div>
                                <h4 className="text-xs font-bold text-rose-400 uppercase tracking-widest mb-3 mt-4">Pontos de Atenção</h4>
                                <ul className="text-xs text-zinc-400 space-y-2">
                                    {offer.cons.map((c, i) => <li key={i} className="flex gap-2"><span className="text-rose-500">•</span> {c}</li>)}
                                </ul>
                            </div>
                        )}
                    </div>
                )}

                {offer.reviews && offer.reviews.length > 0 && (
                    <div>
                         <h4 className="text-xs font-bold text-zinc-500 uppercase tracking-widest mb-3">Opinião de Usuários</h4>
                         <div className="space-y-3">
                             {offer.reviews.map((rev, i) => (
                                 <div key={i} className="bg-white/5 p-3 rounded-xl text-xs text-zinc-400 italic leading-relaxed">
                                     "{rev}"
                                 </div>
                             ))}
                         </div>
                    </div>
                )}
             </div>
        </div>
      </div>
    </div>
  );
};

export default OfferDetailModal;