
export const getOfficialSelic = async (): Promise<number | null> => {
  try {
    // Series 432 is the "Meta Selic" defined by COPOM (Annual % target)
    // Using the proxy to avoid CORS issues if necessary, but BCB often allows direct access or requires a backend.
    // Since we are client-side only, we attempt a fetch. If CORS blocks it, we might need a fallback or a proxy.
    // For this demo, we try direct. If it fails, the Gemini Service fallback handles it.
    
    const response = await fetch('https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json');
    
    if (!response.ok) {
      throw new Error('BCB API Unavailable');
    }

    const data = await response.json();
    // Expected format: [{ data: "dd/mm/yyyy", valor: "10.50" }]
    if (Array.isArray(data) && data.length > 0 && data[0].valor) {
      return parseFloat(data[0].valor);
    }
    return null;
  } catch (error) {
    console.warn("Error fetching official SELIC:", error);
    return null;
  }
};
