import React, { useState, useEffect } from 'react';
import { UserInput, AppStatus, InvestmentType, HistoryItem } from '../types';
import { Icons } from '../constants';

interface InputSectionProps {
  onStartSearch: (input: UserInput) => void;
  onRecalculate: (input: UserInput) => void;
  onRestoreHistory: (item: HistoryItem) => void;
  status: AppStatus;
  initialValues?: UserInput | null;
}

const InputSection: React.FC<InputSectionProps> = ({ onStartSearch, onRecalculate, onRestoreHistory, status, initialValues }) => {
  const [productName, setProductName] = useState('');
  const [yieldPercent, setYieldPercent] = useState(100);
  const [investmentType, setInvestmentType] = useState<InvestmentType>(InvestmentType.CDB_RDB);
  const [customSelic, setCustomSelic] = useState<string>('');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [hasChanged, setHasChanged] = useState(false);

  useEffect(() => {
    if (initialValues) {
      setProductName(initialValues.productName);
      setYieldPercent(initialValues.yieldPercent);
      setInvestmentType(initialValues.investmentType);
      setCustomSelic(initialValues.customSelic ? String(initialValues.customSelic) : '');
    }
  }, [initialValues]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('smartbuy_history');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
            setHistory(parsed.slice(0, 5));
        }
      }
    } catch (e) {
      console.error("Failed to load history", e);
    }
  }, [status]); 

  const handleInputChange = (setter: any, val: any) => {
    setter(val);
    if (status === AppStatus.COMPLETE) setHasChanged(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName.trim()) return;

    const input: UserInput = {
      productName,
      yieldPercent,
      investmentType,
      customSelic: customSelic ? parseFloat(customSelic.replace(',', '.')) : undefined
    };

    if (status === AppStatus.COMPLETE && initialValues && productName === initialValues.productName) {
      onRecalculate(input);
      setHasChanged(false);
    } else {
      onStartSearch(input);
      setHasChanged(false);
    }
  };

  const isLoading = status !== AppStatus.IDLE && status !== AppStatus.COMPLETE && status !== AppStatus.ERROR;

  return (
    <div className="w-full max-w-2xl mx-auto mb-10 space-y-6">
      
      <div className="bg-surface/60 backdrop-blur-xl border border-white/5 rounded-3xl shadow-2xl p-8 relative overflow-hidden transition-all duration-300 hover:border-white/10">
        
        {/* Removed Icon as requested, minimal Header */}
        <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">O que vamos comprar?</h2>
        <p className="text-zinc-500 mb-8 text-sm">Analise ofertas e simule o custo de oportunidade.</p>
        
        <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
          <div className="relative group">
            <input
              type="text"
              required
              disabled={isLoading}
              value={productName}
              onChange={(e) => handleInputChange(setProductName, e.target.value)}
              placeholder=" "
              className="peer w-full bg-midnight-900/50 border border-zinc-800 rounded-xl py-4 px-5 text-white placeholder-transparent focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500 outline-none transition-all"
            />
            <label className="absolute left-5 top-4 text-zinc-500 text-base transition-all peer-placeholder-shown:translate-y-0 peer-placeholder-shown:text-base peer-focus:-translate-y-7 peer-focus:text-xs peer-focus:text-primary-400 peer-[:not(:placeholder-shown)]:-translate-y-7 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:text-zinc-400 pointer-events-none bg-midnight-900/0 px-1">
              Nome do Produto (ex: iPhone 15)
            </label>
            <div className="absolute right-4 top-4 text-zinc-600 peer-focus:text-primary-500 transition-colors">
              <Icons.Search />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-3">
              <label className="text-sm font-medium text-zinc-400">Rentabilidade (% do CDI)</label>
              <span className="text-xs font-bold text-success-400 bg-success-500/10 px-2 py-0.5 rounded border border-success-500/20">{yieldPercent}%</span>
            </div>
            <input
              type="range"
              min="80"
              max="150"
              step="1"
              disabled={isLoading}
              value={yieldPercent}
              onChange={(e) => handleInputChange(setYieldPercent, Number(e.target.value))}
              className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-primary-500 hover:accent-primary-400"
            />
          </div>

          <div>
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center gap-2 text-xs font-semibold text-zinc-500 hover:text-white transition-colors"
            >
              {showAdvanced ? <Icons.ChevronUp /> : <Icons.ChevronDown />}
              Configurações Avançadas
            </button>

            {showAdvanced && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 animate-slide-up">
                <div className="p-3 rounded-2xl bg-zinc-900/50 border border-white/5">
                  <label className="block text-xs font-medium text-zinc-500 mb-2">Tipo de Investimento</label>
                  <div className="flex gap-1 bg-midnight-900 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => handleInputChange(setInvestmentType, InvestmentType.CDB_RDB)}
                      className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all ${investmentType === InvestmentType.CDB_RDB ? 'bg-primary-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
                    >
                      CDB (IR)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleInputChange(setInvestmentType, InvestmentType.LCI_LCA)}
                      className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all ${investmentType === InvestmentType.LCI_LCA ? 'bg-primary-600 text-white shadow-lg' : 'text-zinc-500 hover:text-zinc-300'}`}
                    >
                      LCI (Isento)
                    </button>
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-zinc-900/50 border border-white/5">
                  <label className="block text-xs font-medium text-zinc-500 mb-2">Selic Manual (Opcional)</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Auto"
                      value={customSelic}
                      onChange={(e) => handleInputChange(setCustomSelic, e.target.value)}
                      className="w-full bg-midnight-900 border-none rounded-lg py-2 px-3 text-sm text-white placeholder-zinc-700 focus:ring-1 focus:ring-primary-500/50"
                    />
                    <span className="absolute right-3 top-2 text-xs text-zinc-600 font-medium">% a.a.</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading || !productName}
            className={`w-full py-4 rounded-xl font-bold text-base transition-all shadow-glow
              ${isLoading ? 'bg-zinc-800 text-zinc-500' : hasChanged && status === AppStatus.COMPLETE ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:brightness-110' : 'bg-gradient-to-r from-primary-600 to-accent-500 text-white hover:brightness-110 hover:shadow-glow-accent'}`}
          >
            {isLoading ? 'Processando...' : (hasChanged && status === AppStatus.COMPLETE ? 'Recalcular Agora' : 'Analisar Oportunidade')}
          </button>
        </form>
      </div>

      {/* History Chips */}
      {history.length > 0 && status === AppStatus.IDLE && (
        <div className="animate-fade-in">
          <p className="text-xs font-bold text-zinc-600 uppercase tracking-widest mb-3 pl-1">Buscas Recentes</p>
          <div className="flex flex-wrap gap-2">
            {history.map((item, idx) => (
              <button 
                key={item.timestamp + idx}
                onClick={() => onRestoreHistory(item)}
                className="flex items-center gap-2 px-4 py-2 rounded-full bg-surface border border-white/5 hover:border-primary-500/30 hover:bg-surface-highlight transition-all group"
              >
                <span className="text-sm font-medium text-zinc-300 group-hover:text-white">{item.input.productName}</span>
                <span className="text-[10px] text-zinc-600 bg-midnight-900 px-1.5 py-0.5 rounded group-hover:text-zinc-400">
                    {item.input.yieldPercent}%
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default InputSection;