
import React, { useMemo } from 'react';

interface BalanceChartProps {
  cashPrice: number;
  installmentPrice: number;
  installments: number;
  monthlyYieldRate: number; 
}

const BalanceChart: React.FC<BalanceChartProps> = ({ cashPrice, installmentPrice, installments, monthlyYieldRate }) => {
  
  // Safety guard against NaN
  const safeCashPrice = isNaN(cashPrice) ? 0 : cashPrice;
  const safeInstallmentPrice = isNaN(installmentPrice) ? 0 : installmentPrice;
  const safeInstallments = isNaN(installments) ? 1 : installments;
  const safeYieldRate = isNaN(monthlyYieldRate) ? 0.8 : monthlyYieldRate;

  const points = useMemo(() => {
    // If installments is 0 or undefined, return empty
    if (!safeInstallments && safeInstallments !== 0) return [];

    // Force at least 12 months projection for visualization if it's a "Cash" (1x) offer,
    // otherwise the chart is a single dot or empty.
    const duration = safeInstallments <= 1 ? 12 : safeInstallments;
    
    // If installments is 1, we still calculate payment as if it were a 1x payment or compare against the installment price provided
    // However, to make a useful chart, we usually want to simulate the "Installment Strategy":
    // "What if I kept the cash price in the bank and paid the installments?"
    // If installmentPrice is 0 or same as cashPrice, the logic holds.
    
    // Check for division by zero
    const monthlyPayment = duration > 0 ? safeInstallmentPrice / duration : 0;
    const rateDecimal = safeYieldRate / 100;
    
    let balance = safeCashPrice;
    const result = [{ month: 0, balance: balance }];
    
    for (let i = 1; i <= duration; i++) {
      balance = balance * (1 + rateDecimal);
      balance = balance - monthlyPayment;
      result.push({ month: i, balance });
    }
    return result;
  }, [safeCashPrice, safeInstallmentPrice, safeInstallments, safeYieldRate]);

  if (points.length === 0) return (
    <div className="h-full flex items-center justify-center text-zinc-600 text-xs">
      Sem dados suficientes.
    </div>
  );

  const duration = points.length - 1;
  const width = 100;
  const height = 50;
  const padding = 6; 
  
  const values = points.map(p => p.balance);
  const minVal = Math.min(...values, 0); 
  const maxVal = Math.max(...values, safeCashPrice, safeInstallmentPrice);
  const range = maxVal - minVal || 1; 
  
  const getX = (month: number) => padding + (month / duration) * (width - 2 * padding);
  const getY = (val: number) => height - padding - ((val - minVal) / range) * (height - 2 * padding);

  const pathD = points.map((p, i) => 
    `${i === 0 ? 'M' : 'L'} ${getX(p.month)} ${getY(p.balance)}`
  ).join(' ');

  const finalBalance = points[points.length - 1].balance;
  const isPositiveOutcome = finalBalance > -5; // Margin of error for floating point

  const yZero = getY(0);
  const yCashPrice = getY(safeCashPrice);
  const yInstallment = getY(safeInstallmentPrice);

  // Modern Colors
  const colorPositive = "#2dd4bf"; // Teal-400
  const colorNegative = "#f43f5e"; // Rose-500
  const colorGrid = "#3f3f46"; // Zinc-700

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex justify-between items-end mb-2 px-1">
        <h4 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Simulação ({duration} meses)</h4>
        <div className="text-right">
           <span className={`text-[11px] font-bold block ${isPositiveOutcome ? 'text-success-400' : 'text-rose-400'}`}>
            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(isNaN(finalBalance) ? 0 : finalBalance)}
          </span>
        </div>
      </div>
      <div className="relative flex-1 min-h-[100px]">
        <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="w-full h-full overflow-visible">
          
          {/* Grid Lines */}
          <line x1={padding} y1={yZero} x2={width - padding} y2={yZero} stroke={colorGrid} strokeWidth="0.5" />
          
          <line x1={padding} y1={yCashPrice} x2={width - padding} y2={yCashPrice} stroke={colorPositive} strokeWidth="0.2" strokeDasharray="1 1" opacity="0.5" />
          
          {safeInstallmentPrice <= maxVal && (
             <line x1={padding} y1={yInstallment} x2={width - padding} y2={yInstallment} stroke={colorNegative} strokeWidth="0.2" strokeDasharray="1 1" opacity="0.5" />
          )}

          {/* Area Under Curve Gradient */}
          <defs>
            <linearGradient id="gradientPositive" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={colorPositive} stopOpacity="0.2" />
              <stop offset="100%" stopColor={colorPositive} stopOpacity="0" />
            </linearGradient>
            <linearGradient id="gradientNegative" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor={colorNegative} stopOpacity="0.2" />
              <stop offset="100%" stopColor={colorNegative} stopOpacity="0" />
            </linearGradient>
          </defs>
          
          {/* Path */}
          <path 
            d={pathD} 
            fill="none" 
            stroke={isPositiveOutcome ? colorPositive : colorNegative} 
            strokeWidth="1.2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            vectorEffect="non-scaling-stroke"
            filter="drop-shadow(0px 2px 4px rgba(0,0,0,0.5))"
          />
          
          <circle cx={getX(duration)} cy={getY(finalBalance)} r="2" fill={isPositiveOutcome ? colorPositive : colorNegative} vectorEffect="non-scaling-stroke"/>
        </svg>
      </div>
    </div>
  );
};

export default BalanceChart;
