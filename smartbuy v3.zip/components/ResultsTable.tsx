
import React, { useState, useEffect } from 'react';
import { AnalysisResult, Offer } from '../types';
import { Icons } from '../constants';
import BalanceChart from './BalanceChart';

interface ResultsTableProps {
  data: AnalysisResult;
  onSelectOffer: (offer: Offer) => void;
  onUpdateRationale: (newRationale: string) => void;
}

const formatCurrency = (val: number) => {
  const safeVal = isNaN(val) ? 0 : val;
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(safeVal);
};

const ResultsTable: React.FC<ResultsTableProps> = ({ data, onSelectOffer, onUpdateRationale }) => {
  const { offers, selicRate, userYield, rationale, bestOption, monthlyEffectiveRate } = data;
  const [isEditingRationale, setIsEditingRationale] = useState(false);
  const [localRationale, setLocalRationale] = useState(rationale);
  const [shareLabel, setShareLabel] = useState("Compartilhar");
  
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [filteredOffers, setFilteredOffers] = useState<Offer[]>(offers);

  useEffect(() => {
    setLocalRationale(rationale);
  }, [rationale]);

  useEffect(() => {
    let result = offers;
    const min = parseFloat(minPrice);
    const max = parseFloat(maxPrice);

    if (!isNaN(min)) {
      result = result.filter(o => o.cashPrice >= min);
    }
    if (!isNaN(max)) {
      result = result.filter(o => o.cashPrice <= max);
    }
    setFilteredOffers(result);
  }, [offers, minPrice, maxPrice]);

  if (!bestOption || !offers) return null;

  const handleShare = async () => {
    const text = `SmartBuy 🧠\nProduto: ${bestOption.productName}\nMelhor estratégia: ${bestOption.verdict === 'CASH' ? 'À VISTA (Pix)' : `PARCELADO em ${bestOption.installments}x`}\nEconomia estimada: ${formatCurrency(Math.abs(bestOption.cashDiscount - bestOption.yieldGenerated))}\n\nConfira os detalhes no app!`;
    const url = window.location.href.startsWith('http') ? window.location.href : undefined;
    const fullText = url ? `${text}\n${url}` : text;

    const copyFallback = () => {
        const textArea = document.createElement("textarea");
        textArea.value = fullText;
        
        // Ensure it's not visible but part of DOM
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        textArea.style.top = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            const successful = document.execCommand('copy');
            if (successful) {
                setShareLabel("Copiado!");
                setTimeout(() => setShareLabel("Compartilhar"), 2000);
            } else {
                 setShareLabel("Erro");
                 setTimeout(() => setShareLabel("Compartilhar"), 2000);
            }
        } catch (err) {
            console.error('Fallback: Oops, unable to copy', err);
            setShareLabel("Erro");
            setTimeout(() => setShareLabel("Compartilhar"), 2000);
        }

        document.body.removeChild(textArea);
    };

    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(fullText);
          setShareLabel("Copiado!");
          setTimeout(() => setShareLabel("Compartilhar"), 2000);
      } else {
          throw new Error("Clipboard API unavailable");
      }

      // Try native share if available (Mobile mainly)
      if (navigator.share && url) {
        await navigator.share({ title: 'SmartBuy Verdict', text, url });
      }
    } catch (err) {
       console.debug('Clipboard/Share API failed, using fallback', err);
       copyFallback();
    }
  };

  const handleRationaleBlur = () => {
    setIsEditingRationale(false);
    if (localRationale !== rationale) {
      onUpdateRationale(localRationale);
    }
  };

  // Logic to ensure the chart always has something to render. 
  // If installments is 1 (Cash verdict), we project 12 months to show the comparison line.
  const chartInstallments = bestOption.installments > 1 ? bestOption.installments : 12;
  // If it's a cash verdict, we ensure installmentPrice exists for the simulation (fallback to cashPrice if missing)
  const chartInstallmentPrice = bestOption.installmentPrice > 0 ? bestOption.installmentPrice : bestOption.cashPrice;

  return (
    <div className="w-full space-y-6 animate-slide-up pb-20">
      
      {/* Stats Header - Bento Grid Mini */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-surface border border-white/5 p-5 rounded-2xl flex flex-col justify-between hover:border-white/10 transition-colors">
          <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider">Taxa Selic</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-white">{selicRate.toFixed(2)}%</p>
            <span className="text-xs text-zinc-600 mb-1">a.a.</span>
          </div>
        </div>
        <div className="bg-surface border border-white/5 p-5 rounded-2xl flex flex-col justify-between hover:border-white/10 transition-colors">
          <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider">Rentabilidade</p>
          <div className="flex items-end gap-2">
             <p className="text-2xl font-bold text-success-400">{userYield}%</p>
             <span className="text-xs text-zinc-600 mb-1">CDI</span>
          </div>
        </div>
         <div className="bg-surface border border-white/5 p-5 rounded-2xl flex flex-col justify-between hover:border-white/10 transition-colors">
          <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider">Taxa Efetiva</p>
          <div className="flex items-end gap-2">
            <p className="text-2xl font-bold text-primary-400">{monthlyEffectiveRate?.toFixed(2) || '0.80'}%</p>
            <span className="text-xs text-zinc-600 mb-1">a.m.</span>
          </div>
        </div>
         <button onClick={handleShare} className="bg-surface border border-white/5 p-5 rounded-2xl flex flex-col items-center justify-center gap-2 hover:bg-surface-highlight transition-all group">
             <div className="text-zinc-400 group-hover:text-white transition-colors"><Icons.Share /></div>
             <span className="text-xs font-bold uppercase text-zinc-500 group-hover:text-white tracking-wider transition-all">{shareLabel}</span>
        </button>
      </div>

      {/* Winner Card - Premium Look */}
      <div className="group relative overflow-hidden rounded-3xl p-[1px] bg-gradient-to-br from-primary-500 via-accent-500 to-transparent">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-500/20 to-accent-500/20 blur-xl"></div>
        
        <div className="relative bg-midnight-900/90 backdrop-blur-xl rounded-[23px] p-6 md:p-10">
          <div className="absolute top-6 right-6 flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-success-500"></span>
            </span>
            <span className="text-xs font-bold text-success-400 uppercase tracking-widest">Recomendação da IA</span>
          </div>

          <div className="flex flex-col md:flex-row gap-10">
            <div className="flex-1">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-2 leading-tight">
                {bestOption.verdict === 'CASH' ? 'Compre à Vista' : 'Faça o Parcelamento'}
              </h3>
              <p className="text-lg text-primary-200 mb-8 font-medium">
                {bestOption.productName} na <span className="text-white">{bestOption.store}</span>
              </p>
              
              <div className="mb-8">
                {isEditingRationale ? (
                  <textarea
                    value={localRationale}
                    onChange={(e) => setLocalRationale(e.target.value)}
                    onBlur={handleRationaleBlur}
                    autoFocus
                    className="w-full bg-surface-highlight text-zinc-200 border border-primary-500/30 rounded-xl p-4 text-sm leading-relaxed outline-none focus:ring-1 focus:ring-primary-500 resize-none h-32"
                  />
                ) : (
                  <div 
                    onClick={() => setIsEditingRationale(true)}
                    className="text-zinc-400 text-sm leading-relaxed border-l-2 border-primary-500 pl-4 py-1 hover:text-zinc-200 cursor-text transition-colors"
                  >
                    "{localRationale}"
                  </div>
                )}
              </div>

              <div className="flex gap-8">
                 <div className="flex flex-col">
                    <span className="text-xs text-zinc-500 uppercase font-bold">Preço Final</span>
                    <span className="text-xl font-bold text-white">
                      {formatCurrency(bestOption.verdict === 'CASH' ? bestOption.cashPrice : bestOption.installmentPrice)}
                    </span>
                 </div>
                 <div className="flex flex-col">
                    <span className="text-xs text-zinc-500 uppercase font-bold">Condição</span>
                    <span className="text-xl font-bold text-white flex items-center gap-2">
                      <Icons.Wallet /> {bestOption.paymentMethod || (bestOption.verdict === 'CASH' ? 'Pix' : 'Cartão')}
                    </span>
                 </div>
              </div>

              <button 
                 onClick={() => onSelectOffer(bestOption)}
                 className="mt-8 px-6 py-3 bg-white text-midnight-900 font-bold rounded-xl hover:bg-zinc-200 transition-colors shadow-lg shadow-white/10"
              >
                Detalhes & Customização
              </button>
            </div>

            <div className="w-full md:w-80 flex-shrink-0 bg-surface border border-white/5 rounded-2xl p-4 hover:border-primary-500/30 transition-all cursor-pointer" onClick={() => onSelectOffer(bestOption)}>
               <div className="w-full h-48">
                  <BalanceChart 
                    cashPrice={bestOption.cashPrice}
                    installmentPrice={chartInstallmentPrice}
                    installments={chartInstallments}
                    monthlyYieldRate={monthlyEffectiveRate || 0.8}
                  />
               </div>
               <p className="text-center text-xs text-zinc-500 mt-2">Toque para expandir gráfico</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter & List */}
      <div className="bg-surface border border-white/5 rounded-3xl p-6 md:p-8">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
           <h3 className="text-xl font-bold text-white flex items-center gap-2">
             <Icons.Search /> Outras Ofertas
           </h3>
           <div className="flex gap-2 w-full md:w-auto">
             <input 
               type="number" 
               placeholder="Min R$" 
               value={minPrice}
               onChange={(e) => setMinPrice(e.target.value)}
               className="w-full md:w-32 bg-midnight-900/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:border-primary-500 outline-none"
             />
             <input 
               type="number" 
               placeholder="Max R$" 
               value={maxPrice}
               onChange={(e) => setMaxPrice(e.target.value)}
               className="w-full md:w-32 bg-midnight-900/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:border-primary-500 outline-none"
             />
           </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-zinc-400">
            <thead className="text-xs uppercase font-bold text-zinc-600 border-b border-white/5">
              <tr>
                <th className="px-4 py-3">Loja / Produto</th>
                <th className="px-4 py-3">Pgto</th>
                <th className="px-4 py-3 text-right">À Vista</th>
                <th className="px-4 py-3 text-right">Parcelado</th>
                <th className="px-4 py-3 text-right text-success-500">Desconto</th>
                <th className="px-4 py-3 text-right text-primary-400">Rendimento</th>
                <th className="px-4 py-3 text-center">Veredito</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredOffers.map((offer, idx) => (
                <tr 
                  key={idx} 
                  onClick={() => onSelectOffer(offer)}
                  className="hover:bg-white/5 cursor-pointer transition-colors group"
                >
                  <td className="px-4 py-4">
                    <div className="font-bold text-white group-hover:text-primary-300 transition-colors">{offer.store}</div>
                    <div className="text-xs opacity-70 truncate max-w-[200px]">{offer.productName}</div>
                  </td>
                  <td className="px-4 py-4 text-xs">
                     {offer.verdict === 'INSTALLMENTS' ? `${offer.installments}x` : '1x'}
                  </td>
                  <td className="px-4 py-4 text-right text-zinc-300 font-medium">{formatCurrency(offer.cashPrice)}</td>
                  <td className="px-4 py-4 text-right text-zinc-300 font-medium">{formatCurrency(offer.installmentPrice)}</td>
                  <td className="px-4 py-4 text-right text-success-400 font-bold">{formatCurrency(offer.cashDiscount)}</td>
                  <td className="px-4 py-4 text-right text-primary-400 font-bold">{formatCurrency(offer.yieldGenerated)}</td>
                  <td className="px-4 py-4 text-center">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold border ${
                      offer.verdict === 'CASH' 
                        ? 'bg-success-500/10 text-success-400 border-success-500/20' 
                        : 'bg-primary-500/10 text-primary-400 border-primary-500/20'
                    }`}>
                      {offer.verdict === 'CASH' ? 'À VISTA' : 'PARCELAR'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ResultsTable;
