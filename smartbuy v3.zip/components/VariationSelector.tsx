import React, { useState } from 'react';
import { Variation } from '../types';
import { Icons } from '../constants';

interface VariationSelectorProps {
  variations: Variation[];
  onConfirm: (selectedIds: string[]) => void;
  onCancel: () => void;
}

const VariationSelector: React.FC<VariationSelectorProps> = ({ variations, onConfirm, onCancel }) => {
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const toggle = (id: string) => {
    const next = new Set(selected);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelected(next);
  };

  const toggleAll = () => {
    if (selected.size === variations.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(variations.map(v => v.id)));
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-surface border border-white/5 rounded-3xl p-8 mb-10 animate-fade-in shadow-2xl">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-xl font-bold text-white mb-1">Qual modelo específico?</h2>
          <p className="text-sm text-zinc-500">Selecione as variações para buscar preços.</p>
        </div>
        <button 
          onClick={toggleAll}
          className="text-xs font-bold text-primary-400 hover:text-primary-300 uppercase tracking-wider"
        >
          {selected.size === variations.length ? 'Desmarcar' : 'Todos'}
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
        {variations.map((variant) => {
          const isSelected = selected.has(variant.id);
          return (
            <div 
              key={variant.id}
              onClick={() => toggle(variant.id)}
              className={`cursor-pointer p-4 rounded-xl border transition-all duration-300 flex items-center gap-3 group relative overflow-hidden
                ${isSelected 
                  ? 'bg-primary-500/10 border-primary-500/50' 
                  : 'bg-midnight-900/50 border-white/5 hover:border-white/20'
                }`}
            >
              {isSelected && <div className="absolute inset-0 bg-primary-500/5 blur-md"></div>}
              
              <div className={`relative z-10 w-5 h-5 rounded border flex items-center justify-center transition-colors
                ${isSelected ? 'bg-primary-500 border-primary-500' : 'border-zinc-600 group-hover:border-zinc-400'}`}>
                {isSelected && (
                  <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
                  </svg>
                )}
              </div>
              <span className={`relative z-10 text-sm font-medium ${isSelected ? 'text-white' : 'text-zinc-400 group-hover:text-zinc-200'}`}>
                {variant.name}
              </span>
            </div>
          );
        })}
      </div>

      <div className="flex gap-4">
        <button
          onClick={onCancel}
          className="flex-1 py-3 rounded-xl font-medium text-zinc-400 bg-transparent border border-white/10 hover:bg-white/5 transition-all"
        >
          Cancelar
        </button>
        <button
          onClick={() => onConfirm(Array.from(selected))}
          disabled={selected.size === 0}
          className="flex-1 py-3 rounded-xl font-bold text-white bg-white hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed text-midnight-900 transition-all shadow-lg shadow-white/10"
        >
          Confirmar ({selected.size})
        </button>
      </div>
    </div>
  );
};

export default VariationSelector;