
import { GoogleGenAI } from "@google/genai";
import { AnalysisResult, Variation, UserInput, InvestmentType, Offer } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
}

// Helper to safely parse numbers from AI response which might be strings with currency symbols
const sanitizeNumber = (value: any): number => {
  if (typeof value === 'number') return isNaN(value) ? 0 : value;
  if (typeof value === 'string') {
    // Remove R$, whitespace, non-breaking space
    let clean = value.replace(/[R$\s\u00A0]/g, '');
    
    // Check for Brazilian format (e.g. 1.200,50) -> remove dots, replace comma with dot
    if (clean.includes(',') && clean.indexOf('.') < clean.indexOf(',')) {
       // This looks like 1.200,50
       clean = clean.replace(/\./g, '').replace(',', '.');
    } else if (clean.includes(',')) {
       // Just comma decimal 1200,50
       clean = clean.replace(',', '.');
    }
    
    const num = parseFloat(clean);
    return isNaN(num) ? 0 : num;
  }
  return 0;
};

// Helper to sanitize an entire Offer object
const sanitizeOffer = (offer: any): Offer => {
  return {
    ...offer,
    cashPrice: sanitizeNumber(offer.cashPrice),
    installmentPrice: sanitizeNumber(offer.installmentPrice),
    installments: sanitizeNumber(offer.installments) || 1, // Default to 1 if 0/NaN
    cashDiscount: sanitizeNumber(offer.cashDiscount),
    yieldGenerated: sanitizeNumber(offer.yieldGenerated),
  };
};

// Step 1: Identify Product Variations
export const identifyVariations = async (productName: string): Promise<Variation[]> => {
  const ai = getClient();

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Liste as variações de modelo ou capacidade comuns e disponíveis para compra no Brasil do produto "${productName}". 
    Exemplo para iPhone: ["iPhone 15 128GB", "iPhone 15 256GB", "iPhone 15 Pro"].
    Retorne APENAS um JSON array de strings. Sem markdown.`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  let text = response.text || "[]";
  text = text.replace(/```json/g, '').replace(/```/g, '').trim();

  try {
    const rawList = JSON.parse(text) as string[];
    if (!Array.isArray(rawList)) throw new Error("Not an array");
    return rawList.map(name => ({ id: name, name }));
  } catch (e) {
    console.error("Failed to parse variations", text);
    return [{ id: productName, name: productName }];
  }
};

// Step 2: Search for Market Data
export const searchMarketData = async (variations: string[]): Promise<string> => {
  const ai = getClient();
  
  const query = `Analise as ofertas atuais no Brasil para os seguintes itens ou links:
  ${variations.join('\n')}
  
  INSTRUÇÕES DE BUSCA:
  1. Se o item fornecido for uma URL, acesse o conteúdo dessa página para extrair o preço atual.
  2. Se for um nome de produto, procure nas principais lojas (Amazon, Mercado Livre, Magalu, Kabum, Girafa, Fast Shop).
  
  CRÍTICO - LINKS:
  Você DEVE extrair a URL exata da oferta encontrada pelo Google Search.
  Se o link for longo, não o encurte.
  
  DETALHES DE PAGAMENTO:
  Identifique se o "Preço à Vista" é exclusivo para PIX ou Boleto.
  Identifique se o parcelamento tem juros ou é sem juros.
  
  Retorne um resumo detalhado contendo Links, Preços, Parcelas e Condições.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: query,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });

  return response.text || "Nenhum resultado encontrado.";
};

// Step 3: Analyze Finance Strategy
export const analyzeFinancialStrategy = async (
  marketData: string, 
  userInput: UserInput,
  externalSelic?: number | null
): Promise<AnalysisResult> => {
  const ai = getClient();

  const { yieldPercent, productName, investmentType, customSelic, cashbackPercent } = userInput;

  // Determination of the tax rate logic
  // LCI/LCA = 0% Tax
  // CDB = Standard Income Tax table (using 17.5% as a conservative average for medium term or 22.5% for very short)
  const isTaxFree = investmentType === InvestmentType.LCI_LCA;
  const taxInstruction = isTaxFree 
    ? "CONSIDERE ISENÇÃO TOTAL DE IMPOSTO DE RENDA (LCI/LCA)." 
    : "CONSIDERE IMPOSTO DE RENDA DE 17.5% sobre o rendimento (CDB/RDB).";

  // Priority: Custom Selic > External API Selic > Gemini Knowledge
  let selicInstruction = "";
  if (customSelic) {
    selicInstruction = `USE A TAXA SELIC INFORMADA PELO USUÁRIO: ${customSelic}% ao ano.`;
  } else if (externalSelic) {
    selicInstruction = `USE A TAXA SELIC OFICIAL DO BANCO CENTRAL: ${externalSelic}% ao ano.`;
  } else {
    selicInstruction = `Identifique a Taxa SELIC atual no texto ou use 11.25% ao ano.`;
  }

  const prompt = `
  Você é um Analista Financeiro de Alta Precisão (Português do Brasil).
  
  DADOS DE MERCADO:
  ${marketData}

  PARÂMETROS DO USUÁRIO:
  - Produto: ${productName}
  - Rentabilidade: ${yieldPercent}% do CDI.
  - Tipo de Investimento: ${investmentType} (${isTaxFree ? 'Isento IR' : 'Tributável'}).
  - Cashback Disponível: ${cashbackPercent || 0}% (Se informado, deduza do valor à vista ou parcelado para o cálculo efetivo, mas mostre o preço original).
  
  INSTRUÇÕES FINANCEIRAS:
  ${selicInstruction}
  ${taxInstruction}
  
  ALGORITMO:
  1. Identifique até 10 ofertas válidas.
  2. IMPORTANTE: Extraia o LINK REAL (URL) da oferta. Se não houver link, gere uma URL de busca: "https://www.google.com/search?q=${productName}+loja".
  3. Identifique o "paymentMethod" (ex: "PIX", "BOLETO", "CARTÃO 1X").
  4. Para cada oferta:
     - Calcule a taxa mensal líquida efetiva.
     - Simule o fluxo de caixa mensal (investir o valor à vista e sacar as parcelas).
     - 'Yield_Generated' = Total de juros ganhos na simulação.
     - 'Cash_Discount' = Preço Parcelado - Preço à Vista.
     - Gere 1 breve review fictício ou real (se souber) de um usuário sobre esta loja/produto ("reviews": ["string"]).
     - Liste "pros" e "cons" desta oferta específica.
     
  SAÍDA (JSON Schema):
  {
    "selicRate": number,
    "userYield": number,
    "monthlyEffectiveRate": number (taxa percentual mensal líquida usada no cálculo, ex: 0.85),
    "offers": [
      {
        "store": "string",
        "productName": "string",
        "cashPrice": number,
        "installmentPrice": number,
        "installments": number,
        "cashDiscount": number,
        "yieldGenerated": number,
        "verdict": "CASH" | "INSTALLMENTS",
        "link": "string (URL válida)",
        "exclusiveCondition": "string | null",
        "paymentMethod": "string (ex: 'Pix', 'Cartão')",
        "details": "string",
        "reviews": ["string"],
        "pros": ["string"],
        "cons": ["string"]
      }
    ],
    "bestOption": { ... },
    "rationale": "string"
  }
  
  Retorne APENAS JSON válido.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: 'application/json'
    }
  });

  const text = response.text || "{}";
  
  try {
    const cleanText = text.replace(/```json/g, '').replace(/```/g, '').trim();
    const rawResult = JSON.parse(cleanText);

    // Sanitize and Validate data types
    const offers = Array.isArray(rawResult.offers) ? rawResult.offers.map(sanitizeOffer) : [];
    const bestOption = rawResult.bestOption ? sanitizeOffer(rawResult.bestOption) : null;
    
    const result: AnalysisResult = {
      selicRate: sanitizeNumber(rawResult.selicRate),
      userYield: sanitizeNumber(rawResult.userYield),
      monthlyEffectiveRate: sanitizeNumber(rawResult.monthlyEffectiveRate),
      rationale: rawResult.rationale || "Análise concluída.",
      offers,
      bestOption
    };

    // Validate structure to avoid crashes
    if (!result.bestOption) {
      throw new Error("Resposta da IA mal formatada ou sem melhor opção.");
    }

    return result;
  } catch (e) {
    console.error("Failed to parse analysis JSON", text);
    throw new Error("Erro ao processar dados financeiros.");
  }
};
